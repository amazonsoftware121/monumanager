import express from "express";
import {  } from "../controllers/job.js";

const router = express.Router();

router.get("",)

export default router