import React from "react";
const Forgotpassword = () =>{
    return(
<>
    <h1>Forget Password</h1>
</>
    );
}

export default Forgotpassword;