import { useContext,useState } from 'react';
import { Link,useNavigate } from "react-router-dom";
import { AuthContext } from '../../context/authContext';
import './login.scss';
import Header from "../../components/header/Header";
import PageHeader from "../../components/PageHeader";
import { ThreeDots } from  'react-loader-spinner';

const formWrapper = {
  width: "360px",
}
const Login = () => {
  const [inputs, setInputs] = useState({
    username: "",
    password: "",
  });

  const[loader, setLoader] = useState(false);

  const [err, setErr] = useState(null);

  const navigate = useNavigate()

  const handleChange = (e) => {
    setInputs((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };
  const { login } = useContext(AuthContext);

  const handleLogin = async (e) => {
    setLoader(true);
    e.preventDefault();
    try {
      await login(inputs);
      navigate("/dashboard")
    } catch (err) {
      setErr(err.response.data);
    }
  };


  return (
    <>
    <Header />
    <PageHeader title="Login" />
    <div className="container mt-5">
      <div className="loginPage d-flex aligns-items-center justify-content-center">

        <div className="formWrapper" style={formWrapper}>
          <h3>Login Page</h3>

          <form onSubmit={handleLogin}>
            <div className="form-floating mb-3">
              <input type="text" name="username"  className="form-control" id="floatingInput"  placeholder="Username" onChange={handleChange} required  />
              <label htmlFor="floatingInput">Username</label>
            </div>
            <div className="form-floating">
              <input type="password" name="password"  className="form-control" id="floatingPassword" placeholder="Password" onChange={handleChange} required />
              <label htmlFor="floatingPassword">Password</label>
            </div>

            <div className="d-grid justify-content-center gap-2 mt-3 ">
             { /* <input onClick={handleLogin} type="submit" className="btn btn-primary" value="Login" /> */ }
<button  className='btn btn-primary d-block'>Login</button>
            
{ !loader ? "" : <ThreeDots 
      height="50" 
      width="80" 
      radius="9"
      color="#4fa94d" 
      ariaLabel="three-dots-loading"
      wrapperStyle={{}}
      wrapperClassName=""
      visible={true}
       />}

            </div>


            <p className="forgot-password text-right mt-2">
              Forgot <Link to="/forgotpassword">password?</Link>
            </p>
          
            <p className='text-danger text-center'><strong>{err && err}</strong></p>
          </form>
        </div>
      </div>
    </div>
    </>
  );
}
export default Login;