import React from 'react'

const PageTitle = (props) => {
  return (
    <div className='pageTitle'>
    <h3>{props.title}</h3>
    </div>
  )
}

export default PageTitle