import "./order.scss";

const Order = () => {
  return (
    <div>Order</div>
  )
}

export default Order