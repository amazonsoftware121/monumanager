import "./job.scss"
import Customer from "../customer/Customer"

const Job = () => {
  return (
    <Customer />

  )
}

export default Job