import "./job.scss"

const Job = () => {
  return (
    <div>Job</div>
  )
}

export default Job