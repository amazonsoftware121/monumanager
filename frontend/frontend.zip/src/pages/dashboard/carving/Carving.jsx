import "./carving.scss"

const Carving = () => {
  return (
    <div>Carving</div>
  )
}

export default Carving