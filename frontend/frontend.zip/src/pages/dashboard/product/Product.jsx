import "./product.scss"
import {
    useMutation,
    useQueryClient,
    QueryClient,
    QueryClientProvider,
  } from 'react-query'
  

const product = () => {
  return (
    <div>product</div>
  )
}

export default product