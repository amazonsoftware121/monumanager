import React from "react";

const Error = ()=>{
return(
    <>
        <h1>Sorry, 404 page not found.</h1>
    </>
)
}

export default Error;