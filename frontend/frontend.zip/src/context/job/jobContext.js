import { createContext  } from "react";

const jobContext = createContext();

export default jobContext